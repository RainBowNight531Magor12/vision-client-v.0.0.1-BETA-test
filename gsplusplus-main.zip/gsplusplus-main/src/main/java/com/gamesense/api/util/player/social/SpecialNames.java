package com.gamesense.api.util.player.social;

public class SpecialNames {

    private final String name;

    public SpecialNames(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}