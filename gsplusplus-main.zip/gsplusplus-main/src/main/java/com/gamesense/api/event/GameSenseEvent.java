package com.gamesense.api.event;

import me.zero.alpine.event.type.Cancellable;

public class GameSenseEvent extends Cancellable {

}