package com.gamesense.client.module;

public enum Category {
    Combat,
    Exploits,
    GUI,
    HUD,
    Misc,
    Movement,
    Render,
}