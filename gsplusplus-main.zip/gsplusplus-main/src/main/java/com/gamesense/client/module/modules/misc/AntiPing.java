package com.gamesense.client.module.modules.misc;

import com.gamesense.client.module.Category;
import com.gamesense.client.module.Module;

@Module.Declaration(name = "AntiPing", category = Category.Misc, enabled = true)
public class AntiPing extends Module {

}
